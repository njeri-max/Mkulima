package com.cynthia.mkulimaleo.repository

import com.cynthia.mkulimaleo.data.local.dao.RecordDao
import com.cynthia.mkulimaleo.model.Record
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class RecordRepository @Inject constructor(
    private val recordDao: RecordDao
){
    suspend fun addRecord(record: Record) = recordDao.insertRecord(record)
    suspend fun deleteRecord(record: Record) =recordDao.deleteRecord(record)
    suspend fun updateRecord(record: Record) = recordDao.updateRecord(record)
    fun getRecord(): Flow<List<Record>> = recordDao.getAllRecords()
    fun getTopRecords(): Flow<List<Record>> = recordDao.getTopRecords()
}
