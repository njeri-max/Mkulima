package com.cynthia.mkulimaleo.ui.fragments.record

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.cynthia.mkulimaleo.model.Record
import com.cynthia.mkulimaleo.repository.RecordRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RecordViewModel @Inject constructor(
    private val recordRepository: RecordRepository
): ViewModel() {

    val records = liveData {
        recordRepository.getRecord().collect {
            emit(it)
        }
    }

    fun addRecord(record: Record) = viewModelScope.launch {
        recordRepository.addRecord(record)
    }

    fun deleteRecord(record: Record) = viewModelScope.launch {
        recordRepository.deleteRecord(record)
    }

    fun updateRecord(record: Record) = viewModelScope.launch {
        recordRepository.updateRecord(record)
    }

}