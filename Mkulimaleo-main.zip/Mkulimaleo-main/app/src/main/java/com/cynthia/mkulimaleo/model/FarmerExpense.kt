package com.cynthia.mkulimaleo.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.cynthia.mkulimaleo.utils.Constant

@Entity(tableName = Constant.Database.EXPENSE_TABLE)
data class FarmerExpense(
    @PrimaryKey(autoGenerate = true) var id: Int? = null,
    @ColumnInfo(name = Constant.Database.Expense.TITLE) var title: String,
    @ColumnInfo(name = Constant.Database.Expense.DESCRIPTION) var description: String,
    @ColumnInfo(name = Constant.Database.Expense.AMOUNT) var amount:Float,
    @ColumnInfo(name = Constant.Database.Expense.EXPENSE_DATE) var date: Long,
)