package com.cynthia.mkulimaleo.ui.fragments.new_item.expense

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.cynthia.mkulimaleo.R
import com.cynthia.mkulimaleo.databinding.FragmentNewExpenseBinding
import com.cynthia.mkulimaleo.model.FarmerExpense
import com.cynthia.mkulimaleo.ui.fragments.expense.ExpenseViewModel
import com.cynthia.mkulimaleo.utils.isEmpty
import com.cynthia.mkulimaleo.utils.showError
import com.cynthia.mkulimaleo.utils.showToast
import com.cynthia.mkulimaleo.utils.takeText
import com.google.android.material.datepicker.MaterialDatePicker
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class NewExpenseFragment : Fragment() {

    private var _binding: FragmentNewExpenseBinding? = null
    private val binding: FragmentNewExpenseBinding get() = _binding!!

    private var expenseDate: Long? = null

    private val expenseViewModel: ExpenseViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentNewExpenseBinding.inflate(inflater, container, false)

        setUpUI()

        return binding.root
    }

    private fun setUpUI() {
        with(binding) {

            date.setOnClickListener { showDatePicker() }

            btnAdd.setOnClickListener {
                if (title.isEmpty()) {
                    titleHolder.showError(getString(R.string.field_empty_error))
                } else if (description.isEmpty()) {
                    descriptionHolder.showError(getString(R.string.field_empty_error))
                } else if (amount.isEmpty()) {
                    amountHolder.showError(getString(R.string.field_empty_error))
                } else if (expenseDate == null) {
                    showToast("Date cannot be empty")
                } else {
                    val expense = FarmerExpense(
                        null,
                        title.takeText(),
                        description.takeText(),
                        amount.takeText().toFloat(),
                        expenseDate!!
                    )

                    expenseViewModel.addExpense(expense)
                    clearFields()
                    showToast("Expense Added")
                }
            }

        }
    }

    private fun clearFields() {
        with(binding) {
            title.text?.clear()
            description.text?.clear()
            amount.text?.clear()
            date.text = "Select Date"
        }
    }

    private fun showDatePicker() {
        val datePicker = MaterialDatePicker.Builder.datePicker().apply {
            setTitleText(getString(R.string.select_date))
            setInputMode(MaterialDatePicker.INPUT_MODE_CALENDAR)
            setSelection(MaterialDatePicker.todayInUtcMilliseconds())
        }.build()
        activity?.let {
            datePicker.apply {
                show(it.supportFragmentManager, "DATE_PICKER")
                addOnPositiveButtonClickListener {
                    expenseDate = it
                    val date = this.headerText
                    binding.date.text = date
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }


}