package com.cynthia.mkulimaleo.ui.fragments.new_item.note

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.cynthia.mkulimaleo.R
import com.cynthia.mkulimaleo.databinding.FragmentNewNoteBinding
import com.cynthia.mkulimaleo.model.Note
import com.cynthia.mkulimaleo.ui.fragments.note.NoteViewModel
import com.cynthia.mkulimaleo.utils.showToast
import com.cynthia.mkulimaleo.utils.takeText
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class NewNoteFragment : Fragment() {

    private var _binding: FragmentNewNoteBinding? = null
    private val binding: FragmentNewNoteBinding get() = _binding!!

    private val noteViewModel: NoteViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNewNoteBinding.inflate(inflater, container, false)

        setUpUI()

        return binding.root
    }


    private fun setUpUI() {
        with(binding) {
            btnAdd.setOnClickListener {
                if (noteTitle.text.isEmpty()) showToast("Note title is needed")
                else {
                    val note = Note(
                        null,
                        noteTitle.takeText(),
                        note = noteEdit.takeText(),
                        System.currentTimeMillis()
                    )
                    noteViewModel.addNote(note)
                    clearFields()
                    showToast(getString(R.string.note_added))
                }
            }
        }
    }

    private fun clearFields() {
        with(binding) {
            noteTitle.text.clear()
            noteEdit.text.clear()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}