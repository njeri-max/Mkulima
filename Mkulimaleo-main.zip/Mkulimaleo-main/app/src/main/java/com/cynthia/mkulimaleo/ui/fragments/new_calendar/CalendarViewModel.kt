package com.cynthia.mkulimaleo.ui.fragments.new_calendar

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.cynthia.mkulimaleo.model.FarmerCalendar
import com.cynthia.mkulimaleo.repository.FarmerCalendarRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CalendarViewModel @Inject constructor(
    private val farmerCalendarRepository: FarmerCalendarRepository
): ViewModel() {

    fun addCalendar(calendar: FarmerCalendar) = viewModelScope.launch {
        farmerCalendarRepository.addCalendar(calendar)
    }

    val calendars = liveData{
        farmerCalendarRepository.getCalendars().collect { cals ->
            emit(cals)
        }
    }

    fun deleteCalendar(calendar: FarmerCalendar) = viewModelScope.launch {
        farmerCalendarRepository.deleteCalendar(calendar)
    }

}