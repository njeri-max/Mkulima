package com.cynthia.mkulimaleo.ui.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.cynthia.mkulimaleo.databinding.ActivityNewItemBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class NewItemActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNewItemBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewItemBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title= "New Item"
        }
    }
}