package com.cynthia.mkulimaleo.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.cynthia.mkulimaleo.utils.Constant

@Entity(tableName = Constant.Database.RECORD_TABLE)
data class Record(
    @PrimaryKey(autoGenerate = true) var id: Int? = null,
    @ColumnInfo(name = Constant.Database.Animal.TAG) var tag: String,
    @ColumnInfo(name = Constant.Database.Animal.BREED) var breed: String?,
    @ColumnInfo(name = Constant.Database.Produce.QUANTITY_PRODUCED) var quantityProduced: Float,
    @ColumnInfo(name = Constant.Database.Produce.PREVIOUS_PRODUCE) var previousProduce: Float?,
    @ColumnInfo(name = Constant.Database.Produce.EXPECTED_PRODUCE) var expectedProduce: Float?,
    @ColumnInfo(name = Constant.Database.Note.DATE) var date: Long,
    @ColumnInfo(name = Constant.Database.CREATED_AT) var createdAt: Long
)