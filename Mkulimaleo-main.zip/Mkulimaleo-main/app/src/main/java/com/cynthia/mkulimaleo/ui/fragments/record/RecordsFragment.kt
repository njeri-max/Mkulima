package com.cynthia.mkulimaleo.ui.fragments.record

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cynthia.mkulimaleo.common.CommonAdapter
import com.cynthia.mkulimaleo.common.Directions
import com.cynthia.mkulimaleo.common.ItemDecorator
import com.cynthia.mkulimaleo.common.SwipeToDeleteCallback
import com.cynthia.mkulimaleo.databinding.FragmentRecordsBinding
import com.cynthia.mkulimaleo.model.Record
import com.cynthia.mkulimaleo.utils.hideView
import com.cynthia.mkulimaleo.utils.makeVisible
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class RecordsFragment : Fragment() {

    private var _binding: FragmentRecordsBinding? = null
    private val binding: FragmentRecordsBinding get() = _binding!!

    private lateinit var recordAdapter: CommonAdapter<Record>
    private val recordViewModel: RecordViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRecordsBinding.inflate(inflater, container, false)

        setUpRecyclerView()
        subscribeToUI()

        return binding.root
    }

    private fun setUpRecyclerView() {
        recordAdapter = CommonAdapter {
            RecordViewHolder(it)
        }

        binding.recordRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = recordAdapter
            addItemDecoration(ItemDecorator(Directions.VERTICAL, 5))
        }

        val swipeHandler = object : SwipeToDeleteCallback(requireContext()) {
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val record = recordAdapter.differ.currentList[position]
                recordViewModel.deleteRecord(record)
                Snackbar.make(view!!, "Record deleted", Snackbar.LENGTH_LONG).apply {
                    setAction("UNDO") {
                        recordViewModel.addRecord(record)
                    }
                    show()
                }
            }
        }
        val itemTouchHelper = ItemTouchHelper(swipeHandler)
        itemTouchHelper.attachToRecyclerView(binding.recordRecyclerView)
    }

    private fun subscribeToUI() {
        recordViewModel.records.observe(viewLifecycleOwner) { records ->
            if (records.isEmpty()) {
                binding.recordRecyclerView.hideView()
                binding.noDataLayout.makeVisible()
            } else {
                recordAdapter.differ.submitList(records)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}