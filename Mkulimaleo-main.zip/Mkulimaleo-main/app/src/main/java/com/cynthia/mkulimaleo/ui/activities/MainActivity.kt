package com.cynthia.mkulimaleo.ui.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.navigation.findNavController
import androidx.navigation.ui.setupWithNavController
import com.cynthia.mkulimaleo.R
import com.cynthia.mkulimaleo.databinding.ActivityMainBinding
import com.cynthia.mkulimaleo.utils.showToast
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val navController = this.findNavController(R.id.mainNavHostContainer)
        binding.bottomNavigation.setupWithNavController(navController)

        setUpUI()
    }

    private fun setUpUI() {
        with(binding) {
            fab.setOnClickListener {
                startActivity(Intent(this@MainActivity, NewItemActivity::class.java))
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.top_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            R.id.actionProduce -> {
                showToast("Produce clicked")
            }
        }
        return super.onOptionsItemSelected(item)
    }
}