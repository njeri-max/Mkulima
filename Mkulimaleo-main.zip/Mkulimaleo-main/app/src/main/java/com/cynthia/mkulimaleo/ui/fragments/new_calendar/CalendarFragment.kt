package com.cynthia.mkulimaleo.ui.fragments.new_calendar

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cynthia.mkulimaleo.common.CommonAdapter
import com.cynthia.mkulimaleo.common.Directions
import com.cynthia.mkulimaleo.common.ItemDecorator
import com.cynthia.mkulimaleo.common.SwipeToDeleteCallback
import com.cynthia.mkulimaleo.databinding.FragmentCalendarBinding
import com.cynthia.mkulimaleo.model.FarmerCalendar
import com.cynthia.mkulimaleo.utils.hideView
import com.cynthia.mkulimaleo.utils.makeVisible
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CalendarFragment : Fragment() {

    private var _binding: FragmentCalendarBinding? = null
    private val binding: FragmentCalendarBinding get() = _binding!!

    private val calendarViewModel: CalendarViewModel by viewModels()

    private lateinit var calendarAdapter: CommonAdapter<FarmerCalendar>


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentCalendarBinding.inflate(inflater, container, false)

        setUpRecyclerView()
        subscribeToUI()

        return binding.root
    }

    private fun subscribeToUI() {
        calendarViewModel.calendars.observe(viewLifecycleOwner) { calendars ->
            if (calendars.isEmpty()) {
                binding.calendarRecyclerView.hideView()
                binding.noDataLayout.makeVisible()
            } else {
                calendarAdapter.differ.submitList(calendars)
            }
        }
    }

    private fun setUpRecyclerView() {
        calendarAdapter = CommonAdapter {
            CalendarViewHolder(it)
        }

        binding.calendarRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = calendarAdapter
            addItemDecoration(ItemDecorator(Directions.VERTICAL, 5))
        }

        val swipeHandler = object : SwipeToDeleteCallback(requireContext()) {
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val calendar = calendarAdapter.differ.currentList[position]
                calendarViewModel.deleteCalendar(calendar)
                Snackbar.make(view!!, "Calendar deleted", Snackbar.LENGTH_LONG).apply {
                    setAction("UNDO") {
                        calendarViewModel.addCalendar(calendar)
                    }
                    show()
                }
            }
        }
        val itemTouchHelper = ItemTouchHelper(swipeHandler)
        itemTouchHelper.attachToRecyclerView(binding.calendarRecyclerView)

    }



    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}