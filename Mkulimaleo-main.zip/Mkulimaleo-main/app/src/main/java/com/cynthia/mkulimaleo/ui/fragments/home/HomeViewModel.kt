package com.cynthia.mkulimaleo.ui.fragments.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.cynthia.mkulimaleo.repository.ExpenseRepository
import com.cynthia.mkulimaleo.repository.FarmerCalendarRepository
import com.cynthia.mkulimaleo.repository.RecordRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val recordsRepository: RecordRepository,
    private val calendarRepository: FarmerCalendarRepository,
    private val expenseRepository: ExpenseRepository
): ViewModel() {

    val topCalendars = liveData {
        calendarRepository.getTopCalendars().collect { emit(it) }
    }

    val topRecords = liveData {
        recordsRepository.getTopRecords().collect { emit(it) }
    }

    val totalExpenses = liveData {
        expenseRepository.getTotalExpenses().collect {
            if (it == null) return@collect
            emit(it)
        }
    }

}