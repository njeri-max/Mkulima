package com.cynthia.mkulimaleo.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.cynthia.mkulimaleo.data.local.dao.*
import com.cynthia.mkulimaleo.model.*

@Database(
    entities = [
        Animal::class,
        FarmerExpense::class,
        FarmerCalendar::class,
        Note::class,
        Produce::class,
        Record::class,
    ],
    version = 1,
    exportSchema = true
)
abstract class MkulimaLeoDatabase: RoomDatabase() {
    abstract fun expenseDao(): ExpenseDao
    abstract fun animalDao(): AnimalDao
    abstract fun farmerCalendarDao(): FarmerCalendarDao
    abstract fun noteDao(): NoteDao
    abstract fun produceDao(): ProduceDao
    abstract fun recordDao(): RecordDao
}