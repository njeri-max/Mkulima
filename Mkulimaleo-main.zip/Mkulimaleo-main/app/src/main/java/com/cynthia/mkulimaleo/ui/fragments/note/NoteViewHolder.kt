package com.cynthia.mkulimaleo.ui.fragments.note

import android.view.ViewGroup
import android.widget.TextView
import com.cynthia.mkulimaleo.R
import com.cynthia.mkulimaleo.common.CommonViewHolder
import com.cynthia.mkulimaleo.model.Note
import com.cynthia.mkulimaleo.utils.formatTimeToDate
import com.cynthia.mkulimaleo.utils.smartTruncate

class NoteViewHolder(
    parent: ViewGroup
): CommonViewHolder<Note>(parent, R.layout.note_item) {

    private val noteTitle: TextView = rootView.findViewById(R.id.animalTagTextView)
    private val noteDesc: TextView = rootView.findViewById(R.id.noteDesc)
    private val noteDate: TextView = rootView.findViewById(R.id.noteDate)

    override fun bindItem(item: Note) {

        noteTitle.text = item.title.smartTruncate(30)
        noteDesc.text = item.note?.smartTruncate(100)
        noteDate.text = item.date.formatTimeToDate()

    }
}