package com.cynthia.mkulimaleo.data.local.migrations

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

class MIGRATION_1_2: Migration(1, 2) {

    override fun migrate(database: SupportSQLiteDatabase) {
//        database.execSQL("ALTER TABLE `records` DROP COM")
//        database.execSQL("CREATE TABLE ``")
    }
}