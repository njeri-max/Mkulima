package com.cynthia.mkulimaleo.di

import android.content.Context
import androidx.room.Room
import com.cynthia.mkulimaleo.data.local.MkulimaLeoDatabase
import com.cynthia.mkulimaleo.data.local.dao.ExpenseDao
import com.cynthia.mkulimaleo.data.local.dao.FarmerCalendarDao
import com.cynthia.mkulimaleo.data.local.dao.NoteDao
import com.cynthia.mkulimaleo.data.local.dao.RecordDao
import com.cynthia.mkulimaleo.repository.ExpenseRepository
import com.cynthia.mkulimaleo.repository.FarmerCalendarRepository
import com.cynthia.mkulimaleo.repository.NoteRepository
import com.cynthia.mkulimaleo.repository.RecordRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext appContext: Context
    ) = Room.databaseBuilder(appContext, MkulimaLeoDatabase::class.java, "mkulima.db")
        .fallbackToDestructiveMigration()
        .build()

    @Provides
    @Singleton
    fun provideAnimalDao(database: MkulimaLeoDatabase) = database.animalDao()

    @Provides
    @Singleton
    fun provideExpenseDao(database: MkulimaLeoDatabase) = database.expenseDao()

    @Provides
    @Singleton
    fun provideFarmerCalendarDao(database: MkulimaLeoDatabase) = database.farmerCalendarDao()

    @Provides
    @Singleton
    fun provideNoteDao(database: MkulimaLeoDatabase) = database.noteDao()

    @Provides
    @Singleton
    fun provideProduceDao(database: MkulimaLeoDatabase) = database.produceDao()

    @Provides
    @Singleton
    fun provideRecordDao(database: MkulimaLeoDatabase) = database.recordDao()

    @Provides
    @Singleton
    fun provideExpenseRepo(expenseDao: ExpenseDao) = ExpenseRepository(expenseDao)

    @Provides
    @Singleton
    fun provideCalendarRepo(calendarDao: FarmerCalendarDao) = FarmerCalendarRepository(calendarDao)

    @Provides
    @Singleton
    fun provideNoteRepo(noteDao: NoteDao) = NoteRepository(noteDao)

    @Provides
    @Singleton
    fun provideRecordRepo(recordDao: RecordDao) = RecordRepository(recordDao)



}