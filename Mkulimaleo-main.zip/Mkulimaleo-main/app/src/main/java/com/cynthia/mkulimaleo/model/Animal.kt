package com.cynthia.mkulimaleo.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.cynthia.mkulimaleo.utils.Constant

@Entity(tableName = Constant.Database.ANIMAL_TABLE)
data class Animal(
    @PrimaryKey(autoGenerate = true) var id: Int? = null,
    @ColumnInfo(name = Constant.Database.Animal.NAME) var name: String,
    @ColumnInfo(name = Constant.Database.Animal.BREED) var breed: String,
    @ColumnInfo(name = Constant.Database.Animal.AGE) var age: Float,
    @ColumnInfo(name = Constant.Database.Animal.TAG) var tag: String,
    @ColumnInfo(name = Constant.Database.Animal.ADDITION_DATE) var dateAdded: Long,
)