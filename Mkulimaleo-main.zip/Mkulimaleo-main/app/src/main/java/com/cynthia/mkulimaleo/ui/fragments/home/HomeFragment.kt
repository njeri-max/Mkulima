package com.cynthia.mkulimaleo.ui.fragments.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.cynthia.mkulimaleo.R
import com.cynthia.mkulimaleo.common.CommonAdapter
import com.cynthia.mkulimaleo.databinding.FragmentHomeBinding
import com.cynthia.mkulimaleo.model.FarmerCalendar
import com.cynthia.mkulimaleo.model.Record
import com.google.android.material.divider.MaterialDividerItemDecoration
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding: FragmentHomeBinding get() = _binding!!

    private lateinit var topRecordAdapter: CommonAdapter<Record>
    private lateinit var topCalAdapter: CommonAdapter<FarmerCalendar>

    private val homeViewModel: HomeViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        setUpRecyclerView()
        initUiState()

        return binding.root
    }

    private fun setUpRecyclerView() {
        topCalAdapter = CommonAdapter { ToCalTopViewHolder(it) }
        topRecordAdapter = CommonAdapter { TopRecordViewHolder(it) }
        with(binding) {
            topCalendarRV.apply {
                layoutManager = LinearLayoutManager(requireContext())
                adapter = topCalAdapter
                val divider =
                    MaterialDividerItemDecoration(context, LinearLayoutManager.VERTICAL).apply {
                        dividerColor = ContextCompat.getColor(requireContext(), R.color.greyish)
                    }
                addItemDecoration(divider)
            }

            topRecordsRV.apply {
                layoutManager = LinearLayoutManager(requireContext())
                adapter = topRecordAdapter
                val divider =
                    MaterialDividerItemDecoration(context, LinearLayoutManager.VERTICAL).apply {
                        dividerColor = ContextCompat.getColor(requireContext(), R.color.greyish)
                    }
                addItemDecoration(divider)
            }
        }
    }

    private fun initUiState() {
        homeViewModel.topCalendars.observe(viewLifecycleOwner) {
            topCalAdapter.differ.submitList(it)
        }

        homeViewModel.topRecords.observe(viewLifecycleOwner) {
            topRecordAdapter.differ.submitList(it)
        }

//        homeViewModel.totalExpenses.observe(viewLifecycleOwner){
//            val totalExpenses = it ?: 0f
////            binding.totalExpTxt.text = "Ksh $totalExpenses"
//        }

    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}