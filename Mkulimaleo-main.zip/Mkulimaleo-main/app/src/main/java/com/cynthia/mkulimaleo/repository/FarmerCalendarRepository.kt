package com.cynthia.mkulimaleo.repository

import com.cynthia.mkulimaleo.data.local.dao.FarmerCalendarDao
import com.cynthia.mkulimaleo.model.FarmerCalendar
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class FarmerCalendarRepository @Inject constructor(
    private val farmerCalendarDao: FarmerCalendarDao
) {
    suspend fun addCalendar(farmerCalendar: FarmerCalendar) = farmerCalendarDao.addCalendar(farmerCalendar)
    suspend fun deleteCalendar(farmerCalendar: FarmerCalendar) = farmerCalendarDao.deleteFarmerCalendar(farmerCalendar)
    suspend fun updateCalendar(farmerCalendar: FarmerCalendar) = farmerCalendarDao.updateCalendar(farmerCalendar)
    fun getCalendars(): Flow<List<FarmerCalendar>> = farmerCalendarDao.getAllCalendars()
    fun getTopCalendars(): Flow<List<FarmerCalendar>> = farmerCalendarDao.getTopCalendars()
}