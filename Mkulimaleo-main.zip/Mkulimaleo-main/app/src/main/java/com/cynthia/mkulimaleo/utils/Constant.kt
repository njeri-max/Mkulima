package com.cynthia.mkulimaleo.utils

object Constant {
    object Database {
        const val CALENDAR_TABLE = "farmer_calendar"
        const val NOTE_TABLE = "notes"
        const val RECORD_TABLE = "records"
        const val ANIMAL_TABLE = "animals"
        const val PRODUCE_TABLE = "produce"
        const val EXPENSE_TABLE = "expenses"
        const val ID = "id"

        const val CREATED_AT = "created_at"

        object Calendar {
            const val TITLE = "title"
            const val DESCRIPTION = "description"
            const val DATE = "date"
        }

        object Note {
            const val TITLE = "title"
            const val NOTE = "note"
            const val DATE = "date"
        }

        object Record {
            const val TITLE = "title"
            const val DATE = "date"
            const val ANIMAL_ID = "animal_id"

        }

        object Animal {
            const val NAME = "name"
            const val BREED = "breed"
            const val AGE = "age"
            const val TAG = "tag"
            const val ADDITION_DATE = "date_added"
        }

        object Produce {
            const val PRODUCE_NAME = "name"
            const val ANIMAL_ID = "animal_id"
            const val QUANTITY_PRODUCED = "quantity_produced"
            const val PREVIOUS_PRODUCE = "previous_produce"
            const val EXPECTED_PRODUCE = "expected_produce"
            const val PRODUCE_DATE = "produce_date"
        }

        object Expense {
            const val TITLE = "title"
            const val DESCRIPTION = "description"
            const val AMOUNT = "amount"
            const val EXPENSE_DATE = "expense_date"
        }
    }
}