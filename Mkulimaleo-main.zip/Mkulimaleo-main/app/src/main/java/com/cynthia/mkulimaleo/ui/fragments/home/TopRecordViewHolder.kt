package com.cynthia.mkulimaleo.ui.fragments.home

import android.view.ViewGroup
import android.widget.TextView
import com.cynthia.mkulimaleo.R
import com.cynthia.mkulimaleo.common.CommonViewHolder
import com.cynthia.mkulimaleo.model.Record
import com.cynthia.mkulimaleo.utils.formatTimeToSmallDate

class TopRecordViewHolder(
    parent: ViewGroup
): CommonViewHolder<Record>(parent, R.layout.record_top_item) {

    private val animalTag: TextView = rootView.findViewById(R.id.anim_tag)
    private val recDate: TextView = rootView.findViewById(R.id.rec_date)
    private val qtyProduced: TextView = rootView.findViewById(R.id.qty_produced)

    override fun bindItem(item: Record) {
        animalTag.text = item.tag
        recDate.text = item.date.formatTimeToSmallDate()
        qtyProduced.text = item.quantityProduced.toString()
    }
}