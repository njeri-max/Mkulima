package com.cynthia.mkulimaleo.repository

import com.cynthia.mkulimaleo.data.local.dao.ExpenseDao
import com.cynthia.mkulimaleo.model.FarmerExpense
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ExpenseRepository @Inject constructor(
    private val expenseDao: ExpenseDao
) {

    suspend fun addExpense(farmerExpense: FarmerExpense) = expenseDao.addExpense(farmerExpense)
    suspend fun deleteExpense(farmerExpense: FarmerExpense) =expenseDao.deleteExpense(farmerExpense)
    suspend fun updateExpense(farmerExpense: FarmerExpense) = expenseDao.updateExpense(farmerExpense)
    fun getAllExpenses(): Flow<List<FarmerExpense>> = expenseDao.getAllExpenses()
    fun getTotalExpenses(): Flow<Float> = expenseDao.getTotalExpenses()
}