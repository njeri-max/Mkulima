package com.cynthia.mkulimaleo.repository

import com.cynthia.mkulimaleo.data.local.dao.NoteDao
import com.cynthia.mkulimaleo.model.Note
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class NoteRepository @Inject constructor(
    private val noteDao: NoteDao
) {

    suspend fun addNote(note: Note) = noteDao.insert(note)
    suspend fun deleteNote(note: Note) = noteDao.deleteNote(note)
    suspend fun updateNote(note: Note) = noteDao.updateNote(note)
    fun getNotes(): Flow<List<Note>> = noteDao.getAllNotes()
}