package com.cynthia.mkulimaleo.ui.fragments.expense

import android.view.ViewGroup
import android.widget.TextView
import com.cynthia.mkulimaleo.R
import com.cynthia.mkulimaleo.common.CommonViewHolder
import com.cynthia.mkulimaleo.model.FarmerExpense
import com.cynthia.mkulimaleo.utils.formatTimeToSmallDate
import com.cynthia.mkulimaleo.utils.smartTruncate

class ExpenseViewHolder(
    parent: ViewGroup
): CommonViewHolder<FarmerExpense>(parent, R.layout.expense_item) {

    private val titleText: TextView = rootView.findViewById(R.id.anim_tag)
    private val descText: TextView = rootView.findViewById(R.id.cal_desc)
    private val amountText: TextView = rootView.findViewById(R.id.amountTextView)
    private val dateText: TextView = rootView.findViewById(R.id.cal_date)

    override fun bindItem(item: FarmerExpense) {
        titleText.text = item.title.smartTruncate(20)
        descText.text = item.description.smartTruncate(100)
        amountText.text = "Ksh ${item.amount}"
        dateText.text = item.date.formatTimeToSmallDate()
    }
}