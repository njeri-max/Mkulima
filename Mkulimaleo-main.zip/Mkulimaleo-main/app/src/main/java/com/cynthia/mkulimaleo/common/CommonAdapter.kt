package com.cynthia.mkulimaleo.common

import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView

class CommonAdapter<T>(
    private val viewHolderFactory: ((parent: ViewGroup) -> CommonViewHolder<T>)
): RecyclerView.Adapter<CommonViewHolder<T>>() {

    private var onItemClickListener: ((T?) -> Unit)? = null
    private var onItemLongPressListener: ((T?) -> Unit)? = null

    private val diffCallback = object : DiffUtil.ItemCallback<T>() {
        override fun areItemsTheSame(oldItem: T, newItem: T): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(oldItem: T, newItem: T): Boolean {
            return oldItem.hashCode() == newItem.hashCode()
        }
    }

    val differ = AsyncListDiffer(this, diffCallback)

    fun setOnClickListener(listener: (T?) -> Unit) {
        onItemClickListener = listener
    }

    fun setOnItemLongPressListener(listener: (T?) -> Unit) {
        onItemLongPressListener = listener
    }

    fun removeAt(position: Int) {
        differ.currentList.removeAt(position)
        notifyItemRemoved(position)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CommonViewHolder<T> {
        return viewHolderFactory(parent)
    }

    override fun onBindViewHolder(holder: CommonViewHolder<T>, position: Int) {
        val item = differ.currentList[position]
        holder.apply {
            bindItem(item)
            rootView.setOnClickListener {
                onItemClickListener?.let {
                    it(item)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return differ.currentList.size
    }
}