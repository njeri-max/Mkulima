package com.cynthia.mkulimaleo.ui.fragments.record

import android.view.ViewGroup
import android.widget.TextView
import com.cynthia.mkulimaleo.R
import com.cynthia.mkulimaleo.common.CommonViewHolder
import com.cynthia.mkulimaleo.model.Record
import com.cynthia.mkulimaleo.utils.formatTimeToSmallDate

class RecordViewHolder(
    parent: ViewGroup
): CommonViewHolder<Record>(parent, R.layout.record_item) {

    private val animalTag: TextView = rootView.findViewById(R.id.animalTagTextView)
    private val dateText: TextView = rootView.findViewById(R.id.dateTextView)
    private val quantityProduced: TextView = rootView.findViewById(R.id.quantity_produced_txt)
    private val previousProduce: TextView = rootView.findViewById(R.id.prev_produce_txt)
    private val expectedProduce: TextView = rootView.findViewById(R.id.expected_produce_txt)
    private val breedTextView: TextView = rootView.findViewById(R.id.breed_txt)

    override fun bindItem(item: Record) {
        animalTag.text = item.tag
        dateText.text = item.date.formatTimeToSmallDate()
        quantityProduced.text = item.quantityProduced.toString()
        previousProduce.text = item.previousProduce.toString()
        expectedProduce.text = item.expectedProduce.toString()
        breedTextView.text = item.breed
    }

}