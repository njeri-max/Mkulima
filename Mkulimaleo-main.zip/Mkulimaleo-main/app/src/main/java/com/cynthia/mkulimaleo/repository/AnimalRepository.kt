package com.cynthia.mkulimaleo.repository

import com.cynthia.mkulimaleo.data.local.dao.AnimalDao
import com.cynthia.mkulimaleo.model.Animal
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class AnimalRepository @Inject constructor(
    private val animalDao: AnimalDao
) {

    suspend fun addAnimal(animal: Animal) = animalDao.addAnimal(animal)
    suspend fun deleteAnimal(animal: Animal) = animalDao.deleteAnimal(animal)
    suspend fun updateAnimal(animal: Animal) = animalDao.updateAnimal(animal)
    fun getALlAnimals(): Flow<List<Animal>> = animalDao.getAllAnimals()

}