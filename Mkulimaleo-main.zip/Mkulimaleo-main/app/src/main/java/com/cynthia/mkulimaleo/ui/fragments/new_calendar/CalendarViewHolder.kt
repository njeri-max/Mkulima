package com.cynthia.mkulimaleo.ui.fragments.new_calendar

import android.view.ViewGroup
import android.widget.TextView
import com.cynthia.mkulimaleo.R
import com.cynthia.mkulimaleo.common.CommonViewHolder
import com.cynthia.mkulimaleo.model.FarmerCalendar
import com.cynthia.mkulimaleo.utils.formatTimeToSmallDate
import com.cynthia.mkulimaleo.utils.smartTruncate

class CalendarViewHolder(
    parent: ViewGroup
): CommonViewHolder<FarmerCalendar>(parent, R.layout.calendar_item) {

    private val title: TextView = rootView.findViewById(R.id.animalTagTextView)
    private val description: TextView = rootView.findViewById(R.id.noteDesc)
    private val date: TextView = rootView.findViewById(R.id.noteDate)

    override fun bindItem(item: FarmerCalendar) {
        title.text = item.title
        description.text = item.description.smartTruncate(70)
        date.text = item.date.formatTimeToSmallDate()
    }
}