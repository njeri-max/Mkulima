package com.cynthia.mkulimaleo.repository

import com.cynthia.mkulimaleo.data.local.dao.ProduceDao
import com.cynthia.mkulimaleo.model.Produce
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ProduceRepository @Inject constructor(
    private val produceDao: ProduceDao
) {

    suspend fun addProduce(produce: Produce) = produceDao.insertProduce(produce)
    suspend fun deleteProduce(produce: Produce) = produceDao.deleteProduce(produce)
    suspend fun updateProduce(produce: Produce) = produceDao.updateProduce(produce)
    fun getProduce(): Flow<List<Produce>> = produceDao.getAllProduce()
}