package com.cynthia.mkulimaleo.data.local.dao

import androidx.room.*
import com.cynthia.mkulimaleo.model.Note
import com.cynthia.mkulimaleo.model.Produce
import kotlinx.coroutines.flow.Flow

@Dao
interface ProduceDao {

    @Query("SELECT * FROM produce ORDER BY produce_date DESC")
    fun getAllProduce() : Flow<List<Produce>>

    @Insert
    suspend fun insertProduce(vararg produce: Produce)

    @Delete
    suspend fun deleteProduce(produce: Produce)

    @Update
    suspend fun updateProduce(produce: Produce)

}