package com.cynthia.mkulimaleo.ui.fragments.expense

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cynthia.mkulimaleo.R
import com.cynthia.mkulimaleo.common.CommonAdapter
import com.cynthia.mkulimaleo.common.Directions
import com.cynthia.mkulimaleo.common.ItemDecorator
import com.cynthia.mkulimaleo.common.SwipeToDeleteCallback
import com.cynthia.mkulimaleo.databinding.FragmentExpenseBinding
import com.cynthia.mkulimaleo.model.FarmerExpense
import com.cynthia.mkulimaleo.utils.hideView
import com.cynthia.mkulimaleo.utils.makeVisible
import com.cynthia.mkulimaleo.utils.showToast
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ExpenseFragment : Fragment() {

    private var _binding: FragmentExpenseBinding? = null
    private val binding: FragmentExpenseBinding get() = _binding!!

    private val expenseViewModel: ExpenseViewModel by viewModels()

    private lateinit var mAdapter: CommonAdapter<FarmerExpense>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentExpenseBinding.inflate(inflater, container, false)

        setUpRecyclerView()
        subscribeToUI()

        return binding.root
    }

    private fun setUpRecyclerView() {
        mAdapter = CommonAdapter {
            ExpenseViewHolder(it)
        }

        binding.expenseRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = mAdapter
            addItemDecoration(ItemDecorator(Directions.VERTICAL, 5))
        }

        val swipeHandler = object : SwipeToDeleteCallback(requireContext()) {
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val expense = mAdapter.differ.currentList[position]
                expenseViewModel.deleteExpense(expense)
                Snackbar.make(view!!, "Expense deleted", Snackbar.LENGTH_LONG).apply {
                    setAction("UNDO") {
                        expenseViewModel.addExpense(expense)
                    }
                    show()
                }
            }
        }
        val itemTouchHelper = ItemTouchHelper(swipeHandler)
        itemTouchHelper.attachToRecyclerView(binding.expenseRecyclerView)

    }

    fun subscribeToUI() {
        expenseViewModel.expenses.observe(viewLifecycleOwner) { expenses->
            if (expenses.isEmpty()) {
                binding.expenseRecyclerView.hideView()
                binding.noDataLayout.makeVisible()
            } else {
                mAdapter.differ.submitList(expenses)
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mAdapter.setOnClickListener {
            showToast("$it")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

}