package com.cynthia.mkulimaleo.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.cynthia.mkulimaleo.utils.Constant
import com.cynthia.mkulimaleo.utils.Constant.Database.CALENDAR_TABLE

@Entity(tableName = CALENDAR_TABLE)
data class FarmerCalendar(
    @PrimaryKey(autoGenerate = true) var id: Int? = null,
    @ColumnInfo(name = Constant.Database.Calendar.TITLE) var title: String,
    @ColumnInfo(name = Constant.Database.Calendar.DESCRIPTION) var description: String,
    @ColumnInfo(name = Constant.Database.Calendar.DATE) var date: Long,
)






