package com.cynthia.mkulimaleo.data.local.dao

import androidx.room.*
import com.cynthia.mkulimaleo.model.Animal
import kotlinx.coroutines.flow.Flow

@Dao
interface AnimalDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addAnimal(vararg animal: Animal)

    @Update
    suspend fun updateAnimal(animal: Animal)

    @Query("SELECT * FROM animals ORDER BY date_added DESC")
    fun getAllAnimals(): Flow<List<Animal>>

    @Delete
    suspend fun deleteAnimal(animal: Animal)
}