package com.cynthia.mkulimaleo.ui.fragments.home

import android.view.ViewGroup
import android.widget.TextView
import com.cynthia.mkulimaleo.R
import com.cynthia.mkulimaleo.common.CommonViewHolder
import com.cynthia.mkulimaleo.model.FarmerCalendar
import com.cynthia.mkulimaleo.utils.formatTimeToSmallDate
import com.cynthia.mkulimaleo.utils.smartTruncate

class ToCalTopViewHolder(
    parent: ViewGroup
): CommonViewHolder<FarmerCalendar>(parent, R.layout.calendar_top_item) {

    private val calTitle: TextView = rootView.findViewById(R.id.cal_title)
    private val calDesc: TextView = rootView.findViewById(R.id.cal_desc)
    private val calDate: TextView = rootView.findViewById(R.id.cal_date)

    override fun bindItem(item: FarmerCalendar) {
        calTitle.text = item.title.smartTruncate(20)
        calDesc.text = item.description.smartTruncate(25)
        calDate.text = item.date.formatTimeToSmallDate()
    }
}