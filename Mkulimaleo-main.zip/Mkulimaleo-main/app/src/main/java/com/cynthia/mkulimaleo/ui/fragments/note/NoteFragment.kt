package com.cynthia.mkulimaleo.ui.fragments.note

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cynthia.mkulimaleo.R
import com.cynthia.mkulimaleo.common.CommonAdapter
import com.cynthia.mkulimaleo.common.Directions
import com.cynthia.mkulimaleo.common.ItemDecorator
import com.cynthia.mkulimaleo.common.SwipeToDeleteCallback
import com.cynthia.mkulimaleo.databinding.FragmentNoteBinding
import com.cynthia.mkulimaleo.model.Note
import com.cynthia.mkulimaleo.utils.hideView
import com.cynthia.mkulimaleo.utils.makeVisible
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class NoteFragment : Fragment() {

    private var _binding: FragmentNoteBinding? = null
    private val binding: FragmentNoteBinding get() = _binding!!

    private lateinit var noteAdapter: CommonAdapter<Note>

    private val noteViewModel: NoteViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentNoteBinding.inflate(inflater, container, false)

        setUpRecyclerView()
        subscribeToUI()

        return binding.root
    }

    private fun setUpRecyclerView() {
        noteAdapter = CommonAdapter {
            NoteViewHolder(it)
        }

        binding.noteRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = noteAdapter
            addItemDecoration(ItemDecorator(Directions.VERTICAL, 5))
        }

        val swipeHandler = object : SwipeToDeleteCallback(requireContext()) {
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val note = noteAdapter.differ.currentList[position]
                noteViewModel.deleteNote(note)
                Snackbar.make(view!!, "Note deleted", Snackbar.LENGTH_LONG).apply {
                    setAction("UNDO") {
                        noteViewModel.addNote(note)
                    }
                    show()
                }
            }
        }
        val itemTouchHelper = ItemTouchHelper(swipeHandler)
        itemTouchHelper.attachToRecyclerView(binding.noteRecyclerView)
    }

    private fun subscribeToUI() {
        noteViewModel.notes.observe(viewLifecycleOwner) {
            if (it.isEmpty()) {
                binding.noteRecyclerView.hideView()
                binding.noDataLayout.makeVisible()
            } else noteAdapter.differ.submitList(it)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }


}