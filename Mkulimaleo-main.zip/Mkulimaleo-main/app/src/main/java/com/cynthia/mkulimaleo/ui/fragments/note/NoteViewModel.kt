package com.cynthia.mkulimaleo.ui.fragments.note

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.cynthia.mkulimaleo.model.Note
import com.cynthia.mkulimaleo.repository.NoteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NoteViewModel @Inject constructor(
    private val noteRepository: NoteRepository
): ViewModel() {

    fun addNote(note: Note) = viewModelScope.launch {
        noteRepository.addNote(note)
    }

    val notes = liveData {
        noteRepository.getNotes().collect { emit(it) }
    }

    fun deleteNote(note: Note) = viewModelScope.launch {
        noteRepository.deleteNote(note)
    }

    fun updateNote(note: Note) = viewModelScope.launch {
        noteRepository.updateNote(note)
    }

}