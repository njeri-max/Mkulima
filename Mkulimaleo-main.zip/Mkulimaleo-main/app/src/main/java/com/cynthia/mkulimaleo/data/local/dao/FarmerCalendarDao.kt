package com.cynthia.mkulimaleo.data.local.dao

import androidx.room.*
import com.cynthia.mkulimaleo.model.FarmerCalendar
import kotlinx.coroutines.flow.Flow

@Dao
interface FarmerCalendarDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addCalendar(vararg farmerCalendar: FarmerCalendar)

    @Update
    suspend fun updateCalendar(farmerCalendar: FarmerCalendar)

    @Query("SELECT * FROM farmer_calendar ORDER BY date DESC")
    fun getAllCalendars(): Flow<List<FarmerCalendar>>

    @Query("SELECT * FROM farmer_calendar ORDER BY date DESC LIMIT 5")
    fun getTopCalendars(): Flow<List<FarmerCalendar>>

    @Delete
    suspend fun deleteFarmerCalendar(calendar: FarmerCalendar)

}