package com.cynthia.mkulimaleo.data.local.dao

import androidx.room.*
import com.cynthia.mkulimaleo.model.FarmerExpense
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addExpense(vararg farmerExpense: FarmerExpense)

    @Update
    suspend fun updateExpense(farmerExpense: FarmerExpense)

    @Query("SELECT * FROM expenses ORDER BY expense_date DESC")
    fun getAllExpenses(): Flow<List<FarmerExpense>>

    @Query("SELECT SUM(`amount`) FROM `expenses`")
    fun getTotalExpenses(): Flow<Float>

    @Delete
    suspend fun deleteExpense(farmerExpense: FarmerExpense)
}