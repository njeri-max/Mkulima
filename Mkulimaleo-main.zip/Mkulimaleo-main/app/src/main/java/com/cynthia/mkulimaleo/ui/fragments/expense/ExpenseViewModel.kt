package com.cynthia.mkulimaleo.ui.fragments.expense

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.cynthia.mkulimaleo.model.FarmerExpense
import com.cynthia.mkulimaleo.repository.ExpenseRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ExpenseViewModel @Inject constructor(
    private val expenseRepository: ExpenseRepository
) : ViewModel() {

    fun addExpense(farmerExpense: FarmerExpense) = viewModelScope.launch {
        expenseRepository.addExpense(farmerExpense)
    }

    val expenses = liveData {
        expenseRepository.getAllExpenses().collect { expenses -> emit(expenses) }
    }

    fun deleteExpense(farmerExpense: FarmerExpense) = viewModelScope.launch {
        expenseRepository.deleteExpense(farmerExpense)
    }

    fun updateExpense(farmerExpense: FarmerExpense) = viewModelScope.launch {
        expenseRepository.updateExpense(farmerExpense)
    }

}